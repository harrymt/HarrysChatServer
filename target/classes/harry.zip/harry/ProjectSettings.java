package main;

public class ProjectSettings {
	public static final boolean print_server_method_calls = false;
	public static final boolean print_client_messages = false;
}
